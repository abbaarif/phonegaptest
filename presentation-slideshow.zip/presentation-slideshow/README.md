Presentation Slideshow
=========

A simple presentation template in CSS and jQuery.

[Article on CodyHouse](http://codyhouse.co/gem/presentation-slideshow/)

[Demo](https://codyhouse.co/demo/presentation-slideshow/index.html)
 
[Terms](http://codyhouse.co/terms/)
